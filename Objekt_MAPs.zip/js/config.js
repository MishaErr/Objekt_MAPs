// Если у вас есть OpenRouteService API Key — вставьте сюда.
// Пример:
// const ORS_API_KEY = "your_key_here";
const ORS_API_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjRjZjg3MmFiMDljNzRiN2M4NjBmNTA0NTY5ZTA4Njg3IiwiaCI6Im11cm11cjY0In0="; // если пусто — будет использоваться OSRM (публичный)
